export const environment = {
    production: true,
    apiUrl: 'https://tourism-dklb.onrender.com/api',
    // apiUrl:'https://tourism-backend-1-tw9x.onrender.com/api',
    featureXEnabled: false
};
