export const environment = {
    production: false,
    apiUrl: 'https://tourism-dklb.onrender.com/api',
    // apiUrl: 'http://localhost:4000/api',
    featureXEnabled: true
};
